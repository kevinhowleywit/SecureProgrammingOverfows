//this code is based from an example I found online
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int target;

void attack(char *string)
{
  printf(string);
  
  if(target)
   {
      printf("you have modified the target :)\n");
   }
}

int main(int argc, char **argv)
{
  attack(argv[1]);
}

/*


*/