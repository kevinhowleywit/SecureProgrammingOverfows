
//this code is based of an example in the lecture slides

#include <stdio.h>
 
int main()
{
   int number;
   int number2;
 	//takes in the number and assigns it to int
   printf("Enter an integer\n");
   scanf("%d",&number);
   // takes in another number and assigns it to another int
   printf("Enter another integer\n");
   scanf("%d",&number2);
 	
 //prints number until it overflows
   while(number>number2)
   {
   		number=number*3;
   		printf("number is %d",number);
   }
 
   return 0;
}