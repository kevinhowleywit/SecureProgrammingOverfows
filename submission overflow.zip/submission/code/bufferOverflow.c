//this code was based from an example found online
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

	//setup variables, in this case the username and password
	char ID[5]="";
	char password[10]=" ";


	//prompts the user to enter their ID
	printf("enter your ID. ");


	//scans the user input and places the entry in ID
	scanf("%s",ID);

	//prints the ID that the user specified 
	//and what should be a blank field for the password

	//vunerable to overflow
	printf("The ID entered is  %s \n", ID);
	printf("password not showing %s \n",password);

	return 0;
}

/*
overflows 

123456789123456789123456789

123456789 

the program will oveflow.........last name now

123456789abcdefghijklmopqrstuvwxyz <- overflows here at 't's



tuvwxyz



*/